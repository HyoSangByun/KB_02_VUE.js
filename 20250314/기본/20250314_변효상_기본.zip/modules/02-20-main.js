import getbase, { add, multiply } from './02-19-module.js';

console.log(add(4));
console.log(multiply(2));

console.log(getbase());
